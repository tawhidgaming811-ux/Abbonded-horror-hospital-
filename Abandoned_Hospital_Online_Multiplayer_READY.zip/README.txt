ABANDONED HOSPITAL - ONLINE 2 PLAYER

This is real online room-based multiplayer, not same-device 2P.

1) Install Node.js 18+.
2) Open this folder in a terminal.
3) Run: npm install
4) Run: npm start
5) Open http://localhost:3000 on the host device/browser.
6) Press ENTER HOSPITAL -> MULTIPLAYER -> HOST ROOM.
7) Send the 6-character room code to the second player.
8) Second player opens the same public server address -> JOIN ROOM -> enters code.

IMPORTANT FOR TWO DIFFERENT PHONES:
A localhost address only works on the same device. To play over the Internet, deploy this folder to a Node-compatible hosting service and use its HTTPS URL. The client automatically uses wss:// on HTTPS.

For a same-Wi-Fi test, both phones can use the computer's LAN IP, e.g. http://192.168.x.x:3000, if the firewall allows port 3000.
