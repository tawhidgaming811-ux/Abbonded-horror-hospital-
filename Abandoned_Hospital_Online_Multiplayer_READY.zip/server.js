const http=require('http'), fs=require('fs'), path=require('path');
const WebSocket=require('ws');
const PORT=process.env.PORT||3000;
const rooms=new Map();
const indexPath=path.join(__dirname,'multiplayer_base.html');
function code(){return Math.random().toString(36).slice(2,8).toUpperCase()}
function send(ws,msg){if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(msg))}
const server=http.createServer((req,res)=>{
 let p=req.url.split('?')[0]; if(p==='/'||p==='/index.html')p='/multiplayer_base.html';
 const file=path.join(__dirname,p); if(!file.startsWith(__dirname)||!fs.existsSync(file)){res.writeHead(404);return res.end('Not found')}
 const ext=path.extname(file);const type=ext==='.html'?'text/html':ext==='.js'?'text/javascript':'application/octet-stream';res.writeHead(200,{'Content-Type':type});fs.createReadStream(file).pipe(res);
});
const wss=new WebSocket.Server({server});
wss.on('connection',ws=>{
 ws.room=null;ws.role=null;
 ws.on('message',raw=>{let m;try{m=JSON.parse(raw)}catch(e){return}
  if(m.t==='host'){
   if(ws.room)return; let c;do{c=code()}while(rooms.has(c));rooms.set(c,{host:ws,join:null});ws.room=c;ws.role='host';send(ws,{t:'room',code:c});return;
  }
  if(m.t==='join'){
   const r=rooms.get(String(m.code||'').toUpperCase());
   if(!r||r.join){send(ws,{t:'error',msg:'Room not found or already full.'});return}
   r.join=ws;ws.room=String(m.code).toUpperCase();ws.role='join';send(ws,{t:'joined',code:ws.room});send(r.host,{t:'peer',connected:true});return;
  }
  const r=ws.room&&rooms.get(ws.room);if(!r)return;
  if(m.t==='player'){
   const other=ws.role==='host'?r.join:r.host;send(other,{t:'player',data:m.data});
  } else if(m.t==='world'&&ws.role==='host') send(r.join,{t:'world',ghosts:m.ghosts,boss:m.boss,pickups:m.pickups});
 });
 ws.on('close',()=>{const r=ws.room&&rooms.get(ws.room);if(!r)return;if(ws.role==='host'){send(r.join,{t:'peer',connected:false});if(r.join)r.join.room=null;rooms.delete(ws.room)}else{send(r.host,{t:'peer',connected:false});r.join=null}});
});
server.listen(PORT,()=>console.log(`Abandoned Hospital multiplayer server running on port ${PORT}`));
