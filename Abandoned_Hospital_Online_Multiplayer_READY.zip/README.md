# 👻 Abandoned Hospital — Online Multiplayer

## একদম সহজে চালানোর নিয়ম

এই গেমে দুইজন দুইটা আলাদা ফোন থেকে খেলতে পারবে।

### 1) এই পুরো folder-টা GitHub-এ upload করো
ফাইলগুলো একই folder-এর ভিতরে থাকবে:
- index.html
- multiplayer_base.html
- server.js
- package.json
- render.yaml
- .node-version

### 2) Render-এ যাও
https://render.com খুলে Google/GitHub দিয়ে account বানাও।

### 3) Render → New → Web Service
GitHub repository select করো।

Render নিজে এই settings নেবে:
- Build: `npm install`
- Start: `npm start`
- Free plan

### 4) Deploy শেষ হলে Render একটা HTTPS game link দেবে
উদাহরণ:
https://abandoned-hospital-online.onrender.com

এই একই link দুইজন ফোনে খুলবে।

### 5) Host
ENTER HOSPITAL → MULTIPLAYER → HOST ROOM

একটা code আসবে, যেমন:
A7K9P2

### 6) Join
দ্বিতীয় ফোনে একই link খুলে:
ENTER HOSPITAL → MULTIPLAYER → JOIN ROOM

Host-এর code লিখে JOIN চাপবে।

তারপর দুইজন একই room-এ থাকবে।

## ⚠️ গুরুত্বপূর্ণ
`localhost` বা শুধু HTML file খুললে Internet multiplayer হবে না। Online room-এর জন্য এই Node server-টি চালু থাকতে হবে। Render এই server-টি public HTTPS URL-এ চালাবে এবং WebSocket connection-ও support করে।

## গেমের multiplayer flow
ENTER HOSPITAL
→ SINGLE PLAYER / MULTIPLAYER
→ MULTIPLAYER
→ HOST ROOM / JOIN ROOM

Room সর্বোচ্চ 2 player-এর জন্য তৈরি করা হয়েছে।
